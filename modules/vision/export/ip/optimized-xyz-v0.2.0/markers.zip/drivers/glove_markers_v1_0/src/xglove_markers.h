// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XGLOVE_MARKERS_H
#define XGLOVE_MARKERS_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xglove_markers_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
} XGlove_markers_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XGlove_markers;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XGlove_markers_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XGlove_markers_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XGlove_markers_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XGlove_markers_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XGlove_markers_Initialize(XGlove_markers *InstancePtr, UINTPTR BaseAddress);
XGlove_markers_Config* XGlove_markers_LookupConfig(UINTPTR BaseAddress);
#else
int XGlove_markers_Initialize(XGlove_markers *InstancePtr, u16 DeviceId);
XGlove_markers_Config* XGlove_markers_LookupConfig(u16 DeviceId);
#endif
int XGlove_markers_CfgInitialize(XGlove_markers *InstancePtr, XGlove_markers_Config *ConfigPtr);
#else
int XGlove_markers_Initialize(XGlove_markers *InstancePtr, const char* InstanceName);
int XGlove_markers_Release(XGlove_markers *InstancePtr);
#endif

void XGlove_markers_Start(XGlove_markers *InstancePtr);
u32 XGlove_markers_IsDone(XGlove_markers *InstancePtr);
u32 XGlove_markers_IsIdle(XGlove_markers *InstancePtr);
u32 XGlove_markers_IsReady(XGlove_markers *InstancePtr);
void XGlove_markers_EnableAutoRestart(XGlove_markers *InstancePtr);
void XGlove_markers_DisableAutoRestart(XGlove_markers *InstancePtr);

void XGlove_markers_Set_width(XGlove_markers *InstancePtr, u32 Data);
u32 XGlove_markers_Get_width(XGlove_markers *InstancePtr);
void XGlove_markers_Set_height(XGlove_markers *InstancePtr, u32 Data);
u32 XGlove_markers_Get_height(XGlove_markers *InstancePtr);
void XGlove_markers_Set_min_area(XGlove_markers *InstancePtr, u32 Data);
u32 XGlove_markers_Get_min_area(XGlove_markers *InstancePtr);
void XGlove_markers_Set_max_area(XGlove_markers *InstancePtr, u32 Data);
u32 XGlove_markers_Get_max_area(XGlove_markers *InstancePtr);
void XGlove_markers_Set_frame_id(XGlove_markers *InstancePtr, u32 Data);
u32 XGlove_markers_Get_frame_id(XGlove_markers *InstancePtr);
void XGlove_markers_Set_timestamp_us(XGlove_markers *InstancePtr, u64 Data);
u64 XGlove_markers_Get_timestamp_us(XGlove_markers *InstancePtr);
u32 XGlove_markers_Get_thresholds_BaseAddress(XGlove_markers *InstancePtr);
u32 XGlove_markers_Get_thresholds_HighAddress(XGlove_markers *InstancePtr);
u32 XGlove_markers_Get_thresholds_TotalBytes(XGlove_markers *InstancePtr);
u32 XGlove_markers_Get_thresholds_BitWidth(XGlove_markers *InstancePtr);
u32 XGlove_markers_Get_thresholds_Depth(XGlove_markers *InstancePtr);
u32 XGlove_markers_Write_thresholds_Words(XGlove_markers *InstancePtr, int offset, word_type *data, int length);
u32 XGlove_markers_Read_thresholds_Words(XGlove_markers *InstancePtr, int offset, word_type *data, int length);
u32 XGlove_markers_Write_thresholds_Bytes(XGlove_markers *InstancePtr, int offset, char *data, int length);
u32 XGlove_markers_Read_thresholds_Bytes(XGlove_markers *InstancePtr, int offset, char *data, int length);

void XGlove_markers_InterruptGlobalEnable(XGlove_markers *InstancePtr);
void XGlove_markers_InterruptGlobalDisable(XGlove_markers *InstancePtr);
void XGlove_markers_InterruptEnable(XGlove_markers *InstancePtr, u32 Mask);
void XGlove_markers_InterruptDisable(XGlove_markers *InstancePtr, u32 Mask);
void XGlove_markers_InterruptClear(XGlove_markers *InstancePtr, u32 Mask);
u32 XGlove_markers_InterruptGetEnabled(XGlove_markers *InstancePtr);
u32 XGlove_markers_InterruptGetStatus(XGlove_markers *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
