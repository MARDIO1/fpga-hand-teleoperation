// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
// control
// 0x00 : Control signals
//        bit 0  - ap_start (Read/Write/COH)
//        bit 1  - ap_done (Read/COR)
//        bit 2  - ap_idle (Read)
//        bit 3  - ap_ready (Read/COR)
//        bit 7  - auto_restart (Read/Write)
//        bit 9  - interrupt (Read)
//        others - reserved
// 0x04 : Global Interrupt Enable Register
//        bit 0  - Global Interrupt Enable (Read/Write)
//        others - reserved
// 0x08 : IP Interrupt Enable Register (Read/Write)
//        bit 0 - enable ap_done interrupt (Read/Write)
//        bit 1 - enable ap_ready interrupt (Read/Write)
//        others - reserved
// 0x0c : IP Interrupt Status Register (Read/TOW)
//        bit 0 - ap_done (Read/TOW)
//        bit 1 - ap_ready (Read/TOW)
//        others - reserved
// 0x20 : Data signal of width
//        bit 31~0 - width[31:0] (Read/Write)
// 0x24 : reserved
// 0x28 : Data signal of height
//        bit 31~0 - height[31:0] (Read/Write)
// 0x2c : reserved
// 0x30 : Data signal of min_area
//        bit 31~0 - min_area[31:0] (Read/Write)
// 0x34 : reserved
// 0x38 : Data signal of max_area
//        bit 31~0 - max_area[31:0] (Read/Write)
// 0x3c : reserved
// 0x40 : Data signal of frame_id
//        bit 31~0 - frame_id[31:0] (Read/Write)
// 0x44 : reserved
// 0x48 : Data signal of timestamp_us
//        bit 31~0 - timestamp_us[31:0] (Read/Write)
// 0x4c : Data signal of timestamp_us
//        bit 31~0 - timestamp_us[63:32] (Read/Write)
// 0x50 : reserved
// 0x10 ~
// 0x1f : Memory 'thresholds' (4 * 32b)
//        Word n : bit [31:0] - thresholds[n]
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XGLOVE_MARKERS_CONTROL_ADDR_AP_CTRL           0x00
#define XGLOVE_MARKERS_CONTROL_ADDR_GIE               0x04
#define XGLOVE_MARKERS_CONTROL_ADDR_IER               0x08
#define XGLOVE_MARKERS_CONTROL_ADDR_ISR               0x0c
#define XGLOVE_MARKERS_CONTROL_ADDR_WIDTH_DATA        0x20
#define XGLOVE_MARKERS_CONTROL_BITS_WIDTH_DATA        32
#define XGLOVE_MARKERS_CONTROL_ADDR_HEIGHT_DATA       0x28
#define XGLOVE_MARKERS_CONTROL_BITS_HEIGHT_DATA       32
#define XGLOVE_MARKERS_CONTROL_ADDR_MIN_AREA_DATA     0x30
#define XGLOVE_MARKERS_CONTROL_BITS_MIN_AREA_DATA     32
#define XGLOVE_MARKERS_CONTROL_ADDR_MAX_AREA_DATA     0x38
#define XGLOVE_MARKERS_CONTROL_BITS_MAX_AREA_DATA     32
#define XGLOVE_MARKERS_CONTROL_ADDR_FRAME_ID_DATA     0x40
#define XGLOVE_MARKERS_CONTROL_BITS_FRAME_ID_DATA     32
#define XGLOVE_MARKERS_CONTROL_ADDR_TIMESTAMP_US_DATA 0x48
#define XGLOVE_MARKERS_CONTROL_BITS_TIMESTAMP_US_DATA 64
#define XGLOVE_MARKERS_CONTROL_ADDR_THRESHOLDS_BASE   0x10
#define XGLOVE_MARKERS_CONTROL_ADDR_THRESHOLDS_HIGH   0x1f
#define XGLOVE_MARKERS_CONTROL_WIDTH_THRESHOLDS       32
#define XGLOVE_MARKERS_CONTROL_DEPTH_THRESHOLDS       4

