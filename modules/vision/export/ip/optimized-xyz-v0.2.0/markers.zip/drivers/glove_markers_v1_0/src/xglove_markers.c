// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xglove_markers.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XGlove_markers_CfgInitialize(XGlove_markers *InstancePtr, XGlove_markers_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XGlove_markers_Start(XGlove_markers *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XGlove_markers_ReadReg(InstancePtr->Control_BaseAddress, XGLOVE_MARKERS_CONTROL_ADDR_AP_CTRL) & 0x80;
    XGlove_markers_WriteReg(InstancePtr->Control_BaseAddress, XGLOVE_MARKERS_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XGlove_markers_IsDone(XGlove_markers *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XGlove_markers_ReadReg(InstancePtr->Control_BaseAddress, XGLOVE_MARKERS_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XGlove_markers_IsIdle(XGlove_markers *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XGlove_markers_ReadReg(InstancePtr->Control_BaseAddress, XGLOVE_MARKERS_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XGlove_markers_IsReady(XGlove_markers *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XGlove_markers_ReadReg(InstancePtr->Control_BaseAddress, XGLOVE_MARKERS_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XGlove_markers_EnableAutoRestart(XGlove_markers *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XGlove_markers_WriteReg(InstancePtr->Control_BaseAddress, XGLOVE_MARKERS_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XGlove_markers_DisableAutoRestart(XGlove_markers *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XGlove_markers_WriteReg(InstancePtr->Control_BaseAddress, XGLOVE_MARKERS_CONTROL_ADDR_AP_CTRL, 0);
}

void XGlove_markers_Set_width(XGlove_markers *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XGlove_markers_WriteReg(InstancePtr->Control_BaseAddress, XGLOVE_MARKERS_CONTROL_ADDR_WIDTH_DATA, Data);
}

u32 XGlove_markers_Get_width(XGlove_markers *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XGlove_markers_ReadReg(InstancePtr->Control_BaseAddress, XGLOVE_MARKERS_CONTROL_ADDR_WIDTH_DATA);
    return Data;
}

void XGlove_markers_Set_height(XGlove_markers *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XGlove_markers_WriteReg(InstancePtr->Control_BaseAddress, XGLOVE_MARKERS_CONTROL_ADDR_HEIGHT_DATA, Data);
}

u32 XGlove_markers_Get_height(XGlove_markers *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XGlove_markers_ReadReg(InstancePtr->Control_BaseAddress, XGLOVE_MARKERS_CONTROL_ADDR_HEIGHT_DATA);
    return Data;
}

void XGlove_markers_Set_min_area(XGlove_markers *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XGlove_markers_WriteReg(InstancePtr->Control_BaseAddress, XGLOVE_MARKERS_CONTROL_ADDR_MIN_AREA_DATA, Data);
}

u32 XGlove_markers_Get_min_area(XGlove_markers *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XGlove_markers_ReadReg(InstancePtr->Control_BaseAddress, XGLOVE_MARKERS_CONTROL_ADDR_MIN_AREA_DATA);
    return Data;
}

void XGlove_markers_Set_max_area(XGlove_markers *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XGlove_markers_WriteReg(InstancePtr->Control_BaseAddress, XGLOVE_MARKERS_CONTROL_ADDR_MAX_AREA_DATA, Data);
}

u32 XGlove_markers_Get_max_area(XGlove_markers *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XGlove_markers_ReadReg(InstancePtr->Control_BaseAddress, XGLOVE_MARKERS_CONTROL_ADDR_MAX_AREA_DATA);
    return Data;
}

void XGlove_markers_Set_frame_id(XGlove_markers *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XGlove_markers_WriteReg(InstancePtr->Control_BaseAddress, XGLOVE_MARKERS_CONTROL_ADDR_FRAME_ID_DATA, Data);
}

u32 XGlove_markers_Get_frame_id(XGlove_markers *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XGlove_markers_ReadReg(InstancePtr->Control_BaseAddress, XGLOVE_MARKERS_CONTROL_ADDR_FRAME_ID_DATA);
    return Data;
}

void XGlove_markers_Set_timestamp_us(XGlove_markers *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XGlove_markers_WriteReg(InstancePtr->Control_BaseAddress, XGLOVE_MARKERS_CONTROL_ADDR_TIMESTAMP_US_DATA, (u32)(Data));
    XGlove_markers_WriteReg(InstancePtr->Control_BaseAddress, XGLOVE_MARKERS_CONTROL_ADDR_TIMESTAMP_US_DATA + 4, (u32)(Data >> 32));
}

u64 XGlove_markers_Get_timestamp_us(XGlove_markers *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XGlove_markers_ReadReg(InstancePtr->Control_BaseAddress, XGLOVE_MARKERS_CONTROL_ADDR_TIMESTAMP_US_DATA);
    Data += (u64)XGlove_markers_ReadReg(InstancePtr->Control_BaseAddress, XGLOVE_MARKERS_CONTROL_ADDR_TIMESTAMP_US_DATA + 4) << 32;
    return Data;
}

u32 XGlove_markers_Get_thresholds_BaseAddress(XGlove_markers *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XGLOVE_MARKERS_CONTROL_ADDR_THRESHOLDS_BASE);
}

u32 XGlove_markers_Get_thresholds_HighAddress(XGlove_markers *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XGLOVE_MARKERS_CONTROL_ADDR_THRESHOLDS_HIGH);
}

u32 XGlove_markers_Get_thresholds_TotalBytes(XGlove_markers *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XGLOVE_MARKERS_CONTROL_ADDR_THRESHOLDS_HIGH - XGLOVE_MARKERS_CONTROL_ADDR_THRESHOLDS_BASE + 1);
}

u32 XGlove_markers_Get_thresholds_BitWidth(XGlove_markers *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XGLOVE_MARKERS_CONTROL_WIDTH_THRESHOLDS;
}

u32 XGlove_markers_Get_thresholds_Depth(XGlove_markers *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XGLOVE_MARKERS_CONTROL_DEPTH_THRESHOLDS;
}

u32 XGlove_markers_Write_thresholds_Words(XGlove_markers *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XGLOVE_MARKERS_CONTROL_ADDR_THRESHOLDS_HIGH - XGLOVE_MARKERS_CONTROL_ADDR_THRESHOLDS_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Control_BaseAddress + XGLOVE_MARKERS_CONTROL_ADDR_THRESHOLDS_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XGlove_markers_Read_thresholds_Words(XGlove_markers *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XGLOVE_MARKERS_CONTROL_ADDR_THRESHOLDS_HIGH - XGLOVE_MARKERS_CONTROL_ADDR_THRESHOLDS_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Control_BaseAddress + XGLOVE_MARKERS_CONTROL_ADDR_THRESHOLDS_BASE + (offset + i)*4);
    }
    return length;
}

u32 XGlove_markers_Write_thresholds_Bytes(XGlove_markers *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XGLOVE_MARKERS_CONTROL_ADDR_THRESHOLDS_HIGH - XGLOVE_MARKERS_CONTROL_ADDR_THRESHOLDS_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Control_BaseAddress + XGLOVE_MARKERS_CONTROL_ADDR_THRESHOLDS_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XGlove_markers_Read_thresholds_Bytes(XGlove_markers *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XGLOVE_MARKERS_CONTROL_ADDR_THRESHOLDS_HIGH - XGLOVE_MARKERS_CONTROL_ADDR_THRESHOLDS_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Control_BaseAddress + XGLOVE_MARKERS_CONTROL_ADDR_THRESHOLDS_BASE + offset + i);
    }
    return length;
}

void XGlove_markers_InterruptGlobalEnable(XGlove_markers *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XGlove_markers_WriteReg(InstancePtr->Control_BaseAddress, XGLOVE_MARKERS_CONTROL_ADDR_GIE, 1);
}

void XGlove_markers_InterruptGlobalDisable(XGlove_markers *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XGlove_markers_WriteReg(InstancePtr->Control_BaseAddress, XGLOVE_MARKERS_CONTROL_ADDR_GIE, 0);
}

void XGlove_markers_InterruptEnable(XGlove_markers *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XGlove_markers_ReadReg(InstancePtr->Control_BaseAddress, XGLOVE_MARKERS_CONTROL_ADDR_IER);
    XGlove_markers_WriteReg(InstancePtr->Control_BaseAddress, XGLOVE_MARKERS_CONTROL_ADDR_IER, Register | Mask);
}

void XGlove_markers_InterruptDisable(XGlove_markers *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XGlove_markers_ReadReg(InstancePtr->Control_BaseAddress, XGLOVE_MARKERS_CONTROL_ADDR_IER);
    XGlove_markers_WriteReg(InstancePtr->Control_BaseAddress, XGLOVE_MARKERS_CONTROL_ADDR_IER, Register & (~Mask));
}

void XGlove_markers_InterruptClear(XGlove_markers *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XGlove_markers_WriteReg(InstancePtr->Control_BaseAddress, XGLOVE_MARKERS_CONTROL_ADDR_ISR, Mask);
}

u32 XGlove_markers_InterruptGetEnabled(XGlove_markers *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XGlove_markers_ReadReg(InstancePtr->Control_BaseAddress, XGLOVE_MARKERS_CONTROL_ADDR_IER);
}

u32 XGlove_markers_InterruptGetStatus(XGlove_markers *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XGlove_markers_ReadReg(InstancePtr->Control_BaseAddress, XGLOVE_MARKERS_CONTROL_ADDR_ISR);
}

