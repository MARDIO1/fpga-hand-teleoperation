// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xglove_markers.h"

extern XGlove_markers_Config XGlove_markers_ConfigTable[];

#ifdef SDT
XGlove_markers_Config *XGlove_markers_LookupConfig(UINTPTR BaseAddress) {
	XGlove_markers_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XGlove_markers_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XGlove_markers_ConfigTable[Index].Control_BaseAddress == BaseAddress) {
			ConfigPtr = &XGlove_markers_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XGlove_markers_Initialize(XGlove_markers *InstancePtr, UINTPTR BaseAddress) {
	XGlove_markers_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XGlove_markers_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XGlove_markers_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XGlove_markers_Config *XGlove_markers_LookupConfig(u16 DeviceId) {
	XGlove_markers_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XGLOVE_MARKERS_NUM_INSTANCES; Index++) {
		if (XGlove_markers_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XGlove_markers_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XGlove_markers_Initialize(XGlove_markers *InstancePtr, u16 DeviceId) {
	XGlove_markers_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XGlove_markers_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XGlove_markers_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

