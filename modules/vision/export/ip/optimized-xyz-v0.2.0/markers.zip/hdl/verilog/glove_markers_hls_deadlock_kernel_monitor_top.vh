
wire kernel_monitor_reset;
wire kernel_monitor_clock;
wire kernel_monitor_report;
assign kernel_monitor_reset = ~ap_rst_n;
assign kernel_monitor_clock = ap_clk;
assign kernel_monitor_report = 1'b0;
wire [3:0] axis_block_sigs;
wire [7:0] inst_idle_sigs;
wire [1:0] inst_block_sigs;
wire kernel_block;

assign axis_block_sigs[0] = ~regions_TDATA_blk_n;
assign axis_block_sigs[1] = ~grp_frame_pipeline_fu_235.make_runs_U0.grp_make_runs_Pipeline_VITIS_LOOP_60_1_VITIS_LOOP_64_2_fu_156.pixels_TDATA_blk_n;
assign axis_block_sigs[2] = ~grp_frame_pipeline_fu_235.label_runs_U0.regions_TDATA_blk_n;
assign axis_block_sigs[3] = ~grp_frame_pipeline_fu_235.label_runs_U0.grp_label_runs_Pipeline_VITIS_LOOP_225_5_fu_861.regions_TDATA_blk_n;

assign inst_idle_sigs[0] = grp_frame_pipeline_fu_235.make_runs_U0.ap_idle;
assign inst_block_sigs[0] = (grp_frame_pipeline_fu_235.make_runs_U0.ap_done & ~grp_frame_pipeline_fu_235.make_runs_U0.ap_continue) | ~grp_frame_pipeline_fu_235.make_runs_U0.runs_blk_n | ~grp_frame_pipeline_fu_235.make_runs_U0.grp_make_runs_Pipeline_VITIS_LOOP_60_1_VITIS_LOOP_64_2_fu_156.runs_blk_n;
assign inst_idle_sigs[1] = grp_frame_pipeline_fu_235.label_runs_U0.ap_idle;
assign inst_block_sigs[1] = (grp_frame_pipeline_fu_235.label_runs_U0.ap_done & ~grp_frame_pipeline_fu_235.label_runs_U0.ap_continue) | ~grp_frame_pipeline_fu_235.label_runs_U0.runs_blk_n;

assign inst_idle_sigs[2] = 1'b0;
assign inst_idle_sigs[3] = grp_frame_pipeline_fu_235.ap_idle;
assign inst_idle_sigs[4] = grp_frame_pipeline_fu_235.make_runs_U0.ap_idle;
assign inst_idle_sigs[5] = grp_frame_pipeline_fu_235.make_runs_U0.grp_make_runs_Pipeline_VITIS_LOOP_60_1_VITIS_LOOP_64_2_fu_156.ap_idle;
assign inst_idle_sigs[6] = grp_frame_pipeline_fu_235.label_runs_U0.ap_idle;
assign inst_idle_sigs[7] = grp_frame_pipeline_fu_235.label_runs_U0.grp_label_runs_Pipeline_VITIS_LOOP_225_5_fu_861.ap_idle;

glove_markers_hls_deadlock_idx0_monitor glove_markers_hls_deadlock_idx0_monitor_U (
    .clock(kernel_monitor_clock),
    .reset(kernel_monitor_reset),
    .axis_block_sigs(axis_block_sigs),
    .inst_idle_sigs(inst_idle_sigs),
    .inst_block_sigs(inst_block_sigs),
    .block(kernel_block)
);


always @ (kernel_block or kernel_monitor_reset) begin
    if (kernel_block == 1'b1 && kernel_monitor_reset == 1'b0) begin
        find_kernel_block = 1'b1;
    end
    else begin
        find_kernel_block = 1'b0;
    end
end
