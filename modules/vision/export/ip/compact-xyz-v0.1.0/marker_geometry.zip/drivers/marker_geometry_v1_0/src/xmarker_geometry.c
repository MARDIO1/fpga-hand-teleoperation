// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xmarker_geometry.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XMarker_geometry_CfgInitialize(XMarker_geometry *InstancePtr, XMarker_geometry_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XMarker_geometry_Start(XMarker_geometry *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMarker_geometry_ReadReg(InstancePtr->Control_BaseAddress, XMARKER_GEOMETRY_CONTROL_ADDR_AP_CTRL) & 0x80;
    XMarker_geometry_WriteReg(InstancePtr->Control_BaseAddress, XMARKER_GEOMETRY_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XMarker_geometry_IsDone(XMarker_geometry *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMarker_geometry_ReadReg(InstancePtr->Control_BaseAddress, XMARKER_GEOMETRY_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XMarker_geometry_IsIdle(XMarker_geometry *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMarker_geometry_ReadReg(InstancePtr->Control_BaseAddress, XMARKER_GEOMETRY_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XMarker_geometry_IsReady(XMarker_geometry *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMarker_geometry_ReadReg(InstancePtr->Control_BaseAddress, XMARKER_GEOMETRY_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XMarker_geometry_EnableAutoRestart(XMarker_geometry *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMarker_geometry_WriteReg(InstancePtr->Control_BaseAddress, XMARKER_GEOMETRY_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XMarker_geometry_DisableAutoRestart(XMarker_geometry *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMarker_geometry_WriteReg(InstancePtr->Control_BaseAddress, XMARKER_GEOMETRY_CONTROL_ADDR_AP_CTRL, 0);
}

void XMarker_geometry_Set_count(XMarker_geometry *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMarker_geometry_WriteReg(InstancePtr->Control_BaseAddress, XMARKER_GEOMETRY_CONTROL_ADDR_COUNT_DATA, Data);
}

u32 XMarker_geometry_Get_count(XMarker_geometry *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMarker_geometry_ReadReg(InstancePtr->Control_BaseAddress, XMARKER_GEOMETRY_CONTROL_ADDR_COUNT_DATA);
    return Data;
}

void XMarker_geometry_Set_operation(XMarker_geometry *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMarker_geometry_WriteReg(InstancePtr->Control_BaseAddress, XMARKER_GEOMETRY_CONTROL_ADDR_OPERATION_DATA, Data);
}

u32 XMarker_geometry_Get_operation(XMarker_geometry *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMarker_geometry_ReadReg(InstancePtr->Control_BaseAddress, XMARKER_GEOMETRY_CONTROL_ADDR_OPERATION_DATA);
    return Data;
}

u32 XMarker_geometry_Get_input_r_BaseAddress(XMarker_geometry *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XMARKER_GEOMETRY_CONTROL_ADDR_INPUT_R_BASE);
}

u32 XMarker_geometry_Get_input_r_HighAddress(XMarker_geometry *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XMARKER_GEOMETRY_CONTROL_ADDR_INPUT_R_HIGH);
}

u32 XMarker_geometry_Get_input_r_TotalBytes(XMarker_geometry *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XMARKER_GEOMETRY_CONTROL_ADDR_INPUT_R_HIGH - XMARKER_GEOMETRY_CONTROL_ADDR_INPUT_R_BASE + 1);
}

u32 XMarker_geometry_Get_input_r_BitWidth(XMarker_geometry *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XMARKER_GEOMETRY_CONTROL_WIDTH_INPUT_R;
}

u32 XMarker_geometry_Get_input_r_Depth(XMarker_geometry *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XMARKER_GEOMETRY_CONTROL_DEPTH_INPUT_R;
}

u32 XMarker_geometry_Write_input_r_Words(XMarker_geometry *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XMARKER_GEOMETRY_CONTROL_ADDR_INPUT_R_HIGH - XMARKER_GEOMETRY_CONTROL_ADDR_INPUT_R_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Control_BaseAddress + XMARKER_GEOMETRY_CONTROL_ADDR_INPUT_R_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XMarker_geometry_Read_input_r_Words(XMarker_geometry *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XMARKER_GEOMETRY_CONTROL_ADDR_INPUT_R_HIGH - XMARKER_GEOMETRY_CONTROL_ADDR_INPUT_R_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Control_BaseAddress + XMARKER_GEOMETRY_CONTROL_ADDR_INPUT_R_BASE + (offset + i)*4);
    }
    return length;
}

u32 XMarker_geometry_Write_input_r_Bytes(XMarker_geometry *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XMARKER_GEOMETRY_CONTROL_ADDR_INPUT_R_HIGH - XMARKER_GEOMETRY_CONTROL_ADDR_INPUT_R_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Control_BaseAddress + XMARKER_GEOMETRY_CONTROL_ADDR_INPUT_R_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XMarker_geometry_Read_input_r_Bytes(XMarker_geometry *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XMARKER_GEOMETRY_CONTROL_ADDR_INPUT_R_HIGH - XMARKER_GEOMETRY_CONTROL_ADDR_INPUT_R_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Control_BaseAddress + XMARKER_GEOMETRY_CONTROL_ADDR_INPUT_R_BASE + offset + i);
    }
    return length;
}

u32 XMarker_geometry_Get_output_r_BaseAddress(XMarker_geometry *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XMARKER_GEOMETRY_CONTROL_ADDR_OUTPUT_R_BASE);
}

u32 XMarker_geometry_Get_output_r_HighAddress(XMarker_geometry *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XMARKER_GEOMETRY_CONTROL_ADDR_OUTPUT_R_HIGH);
}

u32 XMarker_geometry_Get_output_r_TotalBytes(XMarker_geometry *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XMARKER_GEOMETRY_CONTROL_ADDR_OUTPUT_R_HIGH - XMARKER_GEOMETRY_CONTROL_ADDR_OUTPUT_R_BASE + 1);
}

u32 XMarker_geometry_Get_output_r_BitWidth(XMarker_geometry *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XMARKER_GEOMETRY_CONTROL_WIDTH_OUTPUT_R;
}

u32 XMarker_geometry_Get_output_r_Depth(XMarker_geometry *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XMARKER_GEOMETRY_CONTROL_DEPTH_OUTPUT_R;
}

u32 XMarker_geometry_Write_output_r_Words(XMarker_geometry *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XMARKER_GEOMETRY_CONTROL_ADDR_OUTPUT_R_HIGH - XMARKER_GEOMETRY_CONTROL_ADDR_OUTPUT_R_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Control_BaseAddress + XMARKER_GEOMETRY_CONTROL_ADDR_OUTPUT_R_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XMarker_geometry_Read_output_r_Words(XMarker_geometry *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XMARKER_GEOMETRY_CONTROL_ADDR_OUTPUT_R_HIGH - XMARKER_GEOMETRY_CONTROL_ADDR_OUTPUT_R_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Control_BaseAddress + XMARKER_GEOMETRY_CONTROL_ADDR_OUTPUT_R_BASE + (offset + i)*4);
    }
    return length;
}

u32 XMarker_geometry_Write_output_r_Bytes(XMarker_geometry *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XMARKER_GEOMETRY_CONTROL_ADDR_OUTPUT_R_HIGH - XMARKER_GEOMETRY_CONTROL_ADDR_OUTPUT_R_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Control_BaseAddress + XMARKER_GEOMETRY_CONTROL_ADDR_OUTPUT_R_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XMarker_geometry_Read_output_r_Bytes(XMarker_geometry *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XMARKER_GEOMETRY_CONTROL_ADDR_OUTPUT_R_HIGH - XMARKER_GEOMETRY_CONTROL_ADDR_OUTPUT_R_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Control_BaseAddress + XMARKER_GEOMETRY_CONTROL_ADDR_OUTPUT_R_BASE + offset + i);
    }
    return length;
}

void XMarker_geometry_InterruptGlobalEnable(XMarker_geometry *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMarker_geometry_WriteReg(InstancePtr->Control_BaseAddress, XMARKER_GEOMETRY_CONTROL_ADDR_GIE, 1);
}

void XMarker_geometry_InterruptGlobalDisable(XMarker_geometry *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMarker_geometry_WriteReg(InstancePtr->Control_BaseAddress, XMARKER_GEOMETRY_CONTROL_ADDR_GIE, 0);
}

void XMarker_geometry_InterruptEnable(XMarker_geometry *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XMarker_geometry_ReadReg(InstancePtr->Control_BaseAddress, XMARKER_GEOMETRY_CONTROL_ADDR_IER);
    XMarker_geometry_WriteReg(InstancePtr->Control_BaseAddress, XMARKER_GEOMETRY_CONTROL_ADDR_IER, Register | Mask);
}

void XMarker_geometry_InterruptDisable(XMarker_geometry *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XMarker_geometry_ReadReg(InstancePtr->Control_BaseAddress, XMARKER_GEOMETRY_CONTROL_ADDR_IER);
    XMarker_geometry_WriteReg(InstancePtr->Control_BaseAddress, XMARKER_GEOMETRY_CONTROL_ADDR_IER, Register & (~Mask));
}

void XMarker_geometry_InterruptClear(XMarker_geometry *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMarker_geometry_WriteReg(InstancePtr->Control_BaseAddress, XMARKER_GEOMETRY_CONTROL_ADDR_ISR, Mask);
}

u32 XMarker_geometry_InterruptGetEnabled(XMarker_geometry *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XMarker_geometry_ReadReg(InstancePtr->Control_BaseAddress, XMARKER_GEOMETRY_CONTROL_ADDR_IER);
}

u32 XMarker_geometry_InterruptGetStatus(XMarker_geometry *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XMarker_geometry_ReadReg(InstancePtr->Control_BaseAddress, XMARKER_GEOMETRY_CONTROL_ADDR_ISR);
}

