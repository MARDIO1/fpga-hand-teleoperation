// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XMARKER_GEOMETRY_H
#define XMARKER_GEOMETRY_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xmarker_geometry_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
} XMarker_geometry_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XMarker_geometry;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XMarker_geometry_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XMarker_geometry_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XMarker_geometry_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XMarker_geometry_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XMarker_geometry_Initialize(XMarker_geometry *InstancePtr, UINTPTR BaseAddress);
XMarker_geometry_Config* XMarker_geometry_LookupConfig(UINTPTR BaseAddress);
#else
int XMarker_geometry_Initialize(XMarker_geometry *InstancePtr, u16 DeviceId);
XMarker_geometry_Config* XMarker_geometry_LookupConfig(u16 DeviceId);
#endif
int XMarker_geometry_CfgInitialize(XMarker_geometry *InstancePtr, XMarker_geometry_Config *ConfigPtr);
#else
int XMarker_geometry_Initialize(XMarker_geometry *InstancePtr, const char* InstanceName);
int XMarker_geometry_Release(XMarker_geometry *InstancePtr);
#endif

void XMarker_geometry_Start(XMarker_geometry *InstancePtr);
u32 XMarker_geometry_IsDone(XMarker_geometry *InstancePtr);
u32 XMarker_geometry_IsIdle(XMarker_geometry *InstancePtr);
u32 XMarker_geometry_IsReady(XMarker_geometry *InstancePtr);
void XMarker_geometry_EnableAutoRestart(XMarker_geometry *InstancePtr);
void XMarker_geometry_DisableAutoRestart(XMarker_geometry *InstancePtr);

void XMarker_geometry_Set_count(XMarker_geometry *InstancePtr, u32 Data);
u32 XMarker_geometry_Get_count(XMarker_geometry *InstancePtr);
void XMarker_geometry_Set_operation(XMarker_geometry *InstancePtr, u32 Data);
u32 XMarker_geometry_Get_operation(XMarker_geometry *InstancePtr);
u32 XMarker_geometry_Get_input_r_BaseAddress(XMarker_geometry *InstancePtr);
u32 XMarker_geometry_Get_input_r_HighAddress(XMarker_geometry *InstancePtr);
u32 XMarker_geometry_Get_input_r_TotalBytes(XMarker_geometry *InstancePtr);
u32 XMarker_geometry_Get_input_r_BitWidth(XMarker_geometry *InstancePtr);
u32 XMarker_geometry_Get_input_r_Depth(XMarker_geometry *InstancePtr);
u32 XMarker_geometry_Write_input_r_Words(XMarker_geometry *InstancePtr, int offset, word_type *data, int length);
u32 XMarker_geometry_Read_input_r_Words(XMarker_geometry *InstancePtr, int offset, word_type *data, int length);
u32 XMarker_geometry_Write_input_r_Bytes(XMarker_geometry *InstancePtr, int offset, char *data, int length);
u32 XMarker_geometry_Read_input_r_Bytes(XMarker_geometry *InstancePtr, int offset, char *data, int length);
u32 XMarker_geometry_Get_output_r_BaseAddress(XMarker_geometry *InstancePtr);
u32 XMarker_geometry_Get_output_r_HighAddress(XMarker_geometry *InstancePtr);
u32 XMarker_geometry_Get_output_r_TotalBytes(XMarker_geometry *InstancePtr);
u32 XMarker_geometry_Get_output_r_BitWidth(XMarker_geometry *InstancePtr);
u32 XMarker_geometry_Get_output_r_Depth(XMarker_geometry *InstancePtr);
u32 XMarker_geometry_Write_output_r_Words(XMarker_geometry *InstancePtr, int offset, word_type *data, int length);
u32 XMarker_geometry_Read_output_r_Words(XMarker_geometry *InstancePtr, int offset, word_type *data, int length);
u32 XMarker_geometry_Write_output_r_Bytes(XMarker_geometry *InstancePtr, int offset, char *data, int length);
u32 XMarker_geometry_Read_output_r_Bytes(XMarker_geometry *InstancePtr, int offset, char *data, int length);

void XMarker_geometry_InterruptGlobalEnable(XMarker_geometry *InstancePtr);
void XMarker_geometry_InterruptGlobalDisable(XMarker_geometry *InstancePtr);
void XMarker_geometry_InterruptEnable(XMarker_geometry *InstancePtr, u32 Mask);
void XMarker_geometry_InterruptDisable(XMarker_geometry *InstancePtr, u32 Mask);
void XMarker_geometry_InterruptClear(XMarker_geometry *InstancePtr, u32 Mask);
u32 XMarker_geometry_InterruptGetEnabled(XMarker_geometry *InstancePtr);
u32 XMarker_geometry_InterruptGetStatus(XMarker_geometry *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
