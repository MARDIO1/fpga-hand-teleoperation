// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
// control
// 0x0000 : Control signals
//          bit 0  - ap_start (Read/Write/COH)
//          bit 1  - ap_done (Read/COR)
//          bit 2  - ap_idle (Read)
//          bit 3  - ap_ready (Read/COR)
//          bit 7  - auto_restart (Read/Write)
//          bit 9  - interrupt (Read)
//          others - reserved
// 0x0004 : Global Interrupt Enable Register
//          bit 0  - Global Interrupt Enable (Read/Write)
//          others - reserved
// 0x0008 : IP Interrupt Enable Register (Read/Write)
//          bit 0 - enable ap_done interrupt (Read/Write)
//          bit 1 - enable ap_ready interrupt (Read/Write)
//          others - reserved
// 0x000c : IP Interrupt Status Register (Read/TOW)
//          bit 0 - ap_done (Read/TOW)
//          bit 1 - ap_ready (Read/TOW)
//          others - reserved
// 0x0010 : Data signal of count
//          bit 31~0 - count[31:0] (Read/Write)
// 0x0014 : reserved
// 0x0018 : Data signal of operation
//          bit 31~0 - operation[31:0] (Read/Write)
// 0x001c : reserved
// 0x2000 ~
// 0x3fff : Memory 'input_r' (1024 * 64b)
//          Word 2n   : bit [31:0] - input_r[n][31: 0]
//          Word 2n+1 : bit [31:0] - input_r[n][63:32]
// 0x4000 ~
// 0x5fff : Memory 'output_r' (1024 * 64b)
//          Word 2n   : bit [31:0] - output_r[n][31: 0]
//          Word 2n+1 : bit [31:0] - output_r[n][63:32]
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XMARKER_GEOMETRY_CONTROL_ADDR_AP_CTRL        0x0000
#define XMARKER_GEOMETRY_CONTROL_ADDR_GIE            0x0004
#define XMARKER_GEOMETRY_CONTROL_ADDR_IER            0x0008
#define XMARKER_GEOMETRY_CONTROL_ADDR_ISR            0x000c
#define XMARKER_GEOMETRY_CONTROL_ADDR_COUNT_DATA     0x0010
#define XMARKER_GEOMETRY_CONTROL_BITS_COUNT_DATA     32
#define XMARKER_GEOMETRY_CONTROL_ADDR_OPERATION_DATA 0x0018
#define XMARKER_GEOMETRY_CONTROL_BITS_OPERATION_DATA 32
#define XMARKER_GEOMETRY_CONTROL_ADDR_INPUT_R_BASE   0x2000
#define XMARKER_GEOMETRY_CONTROL_ADDR_INPUT_R_HIGH   0x3fff
#define XMARKER_GEOMETRY_CONTROL_WIDTH_INPUT_R       64
#define XMARKER_GEOMETRY_CONTROL_DEPTH_INPUT_R       1024
#define XMARKER_GEOMETRY_CONTROL_ADDR_OUTPUT_R_BASE  0x4000
#define XMARKER_GEOMETRY_CONTROL_ADDR_OUTPUT_R_HIGH  0x5fff
#define XMARKER_GEOMETRY_CONTROL_WIDTH_OUTPUT_R      64
#define XMARKER_GEOMETRY_CONTROL_DEPTH_OUTPUT_R      1024

