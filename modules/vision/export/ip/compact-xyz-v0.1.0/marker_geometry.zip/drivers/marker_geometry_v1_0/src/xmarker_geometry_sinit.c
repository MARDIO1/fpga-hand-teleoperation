// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xmarker_geometry.h"

extern XMarker_geometry_Config XMarker_geometry_ConfigTable[];

#ifdef SDT
XMarker_geometry_Config *XMarker_geometry_LookupConfig(UINTPTR BaseAddress) {
	XMarker_geometry_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XMarker_geometry_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XMarker_geometry_ConfigTable[Index].Control_BaseAddress == BaseAddress) {
			ConfigPtr = &XMarker_geometry_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XMarker_geometry_Initialize(XMarker_geometry *InstancePtr, UINTPTR BaseAddress) {
	XMarker_geometry_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XMarker_geometry_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XMarker_geometry_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XMarker_geometry_Config *XMarker_geometry_LookupConfig(u16 DeviceId) {
	XMarker_geometry_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XMARKER_GEOMETRY_NUM_INSTANCES; Index++) {
		if (XMarker_geometry_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XMarker_geometry_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XMarker_geometry_Initialize(XMarker_geometry *InstancePtr, u16 DeviceId) {
	XMarker_geometry_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XMarker_geometry_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XMarker_geometry_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

