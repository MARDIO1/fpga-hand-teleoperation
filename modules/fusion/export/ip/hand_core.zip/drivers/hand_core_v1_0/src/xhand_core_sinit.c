// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xhand_core.h"

extern XHand_core_Config XHand_core_ConfigTable[];

#ifdef SDT
XHand_core_Config *XHand_core_LookupConfig(UINTPTR BaseAddress) {
	XHand_core_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XHand_core_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XHand_core_ConfigTable[Index].Control_BaseAddress == BaseAddress) {
			ConfigPtr = &XHand_core_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XHand_core_Initialize(XHand_core *InstancePtr, UINTPTR BaseAddress) {
	XHand_core_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XHand_core_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XHand_core_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XHand_core_Config *XHand_core_LookupConfig(u16 DeviceId) {
	XHand_core_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XHAND_CORE_NUM_INSTANCES; Index++) {
		if (XHand_core_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XHand_core_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XHand_core_Initialize(XHand_core *InstancePtr, u16 DeviceId) {
	XHand_core_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XHand_core_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XHand_core_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

