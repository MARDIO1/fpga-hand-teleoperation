// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xhand_core.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XHand_core_CfgInitialize(XHand_core *InstancePtr, XHand_core_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XHand_core_Start(XHand_core *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XHand_core_ReadReg(InstancePtr->Control_BaseAddress, XHAND_CORE_CONTROL_ADDR_AP_CTRL) & 0x80;
    XHand_core_WriteReg(InstancePtr->Control_BaseAddress, XHAND_CORE_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XHand_core_IsDone(XHand_core *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XHand_core_ReadReg(InstancePtr->Control_BaseAddress, XHAND_CORE_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XHand_core_IsIdle(XHand_core *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XHand_core_ReadReg(InstancePtr->Control_BaseAddress, XHAND_CORE_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XHand_core_IsReady(XHand_core *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XHand_core_ReadReg(InstancePtr->Control_BaseAddress, XHAND_CORE_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XHand_core_EnableAutoRestart(XHand_core *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XHand_core_WriteReg(InstancePtr->Control_BaseAddress, XHAND_CORE_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XHand_core_DisableAutoRestart(XHand_core *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XHand_core_WriteReg(InstancePtr->Control_BaseAddress, XHAND_CORE_CONTROL_ADDR_AP_CTRL, 0);
}

void XHand_core_Set_reset(XHand_core *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XHand_core_WriteReg(InstancePtr->Control_BaseAddress, XHAND_CORE_CONTROL_ADDR_RESET_DATA, Data);
}

u32 XHand_core_Get_reset(XHand_core *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XHand_core_ReadReg(InstancePtr->Control_BaseAddress, XHAND_CORE_CONTROL_ADDR_RESET_DATA);
    return Data;
}

u32 XHand_core_Get_input_r_BaseAddress(XHand_core *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XHAND_CORE_CONTROL_ADDR_INPUT_R_BASE);
}

u32 XHand_core_Get_input_r_HighAddress(XHand_core *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XHAND_CORE_CONTROL_ADDR_INPUT_R_HIGH);
}

u32 XHand_core_Get_input_r_TotalBytes(XHand_core *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XHAND_CORE_CONTROL_ADDR_INPUT_R_HIGH - XHAND_CORE_CONTROL_ADDR_INPUT_R_BASE + 1);
}

u32 XHand_core_Get_input_r_BitWidth(XHand_core *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XHAND_CORE_CONTROL_WIDTH_INPUT_R;
}

u32 XHand_core_Get_input_r_Depth(XHand_core *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XHAND_CORE_CONTROL_DEPTH_INPUT_R;
}

u32 XHand_core_Write_input_r_Words(XHand_core *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XHAND_CORE_CONTROL_ADDR_INPUT_R_HIGH - XHAND_CORE_CONTROL_ADDR_INPUT_R_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Control_BaseAddress + XHAND_CORE_CONTROL_ADDR_INPUT_R_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XHand_core_Read_input_r_Words(XHand_core *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XHAND_CORE_CONTROL_ADDR_INPUT_R_HIGH - XHAND_CORE_CONTROL_ADDR_INPUT_R_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Control_BaseAddress + XHAND_CORE_CONTROL_ADDR_INPUT_R_BASE + (offset + i)*4);
    }
    return length;
}

u32 XHand_core_Write_input_r_Bytes(XHand_core *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XHAND_CORE_CONTROL_ADDR_INPUT_R_HIGH - XHAND_CORE_CONTROL_ADDR_INPUT_R_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Control_BaseAddress + XHAND_CORE_CONTROL_ADDR_INPUT_R_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XHand_core_Read_input_r_Bytes(XHand_core *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XHAND_CORE_CONTROL_ADDR_INPUT_R_HIGH - XHAND_CORE_CONTROL_ADDR_INPUT_R_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Control_BaseAddress + XHAND_CORE_CONTROL_ADDR_INPUT_R_BASE + offset + i);
    }
    return length;
}

u32 XHand_core_Get_output_r_BaseAddress(XHand_core *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XHAND_CORE_CONTROL_ADDR_OUTPUT_R_BASE);
}

u32 XHand_core_Get_output_r_HighAddress(XHand_core *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XHAND_CORE_CONTROL_ADDR_OUTPUT_R_HIGH);
}

u32 XHand_core_Get_output_r_TotalBytes(XHand_core *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XHAND_CORE_CONTROL_ADDR_OUTPUT_R_HIGH - XHAND_CORE_CONTROL_ADDR_OUTPUT_R_BASE + 1);
}

u32 XHand_core_Get_output_r_BitWidth(XHand_core *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XHAND_CORE_CONTROL_WIDTH_OUTPUT_R;
}

u32 XHand_core_Get_output_r_Depth(XHand_core *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XHAND_CORE_CONTROL_DEPTH_OUTPUT_R;
}

u32 XHand_core_Write_output_r_Words(XHand_core *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XHAND_CORE_CONTROL_ADDR_OUTPUT_R_HIGH - XHAND_CORE_CONTROL_ADDR_OUTPUT_R_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Control_BaseAddress + XHAND_CORE_CONTROL_ADDR_OUTPUT_R_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XHand_core_Read_output_r_Words(XHand_core *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XHAND_CORE_CONTROL_ADDR_OUTPUT_R_HIGH - XHAND_CORE_CONTROL_ADDR_OUTPUT_R_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Control_BaseAddress + XHAND_CORE_CONTROL_ADDR_OUTPUT_R_BASE + (offset + i)*4);
    }
    return length;
}

u32 XHand_core_Write_output_r_Bytes(XHand_core *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XHAND_CORE_CONTROL_ADDR_OUTPUT_R_HIGH - XHAND_CORE_CONTROL_ADDR_OUTPUT_R_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Control_BaseAddress + XHAND_CORE_CONTROL_ADDR_OUTPUT_R_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XHand_core_Read_output_r_Bytes(XHand_core *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XHAND_CORE_CONTROL_ADDR_OUTPUT_R_HIGH - XHAND_CORE_CONTROL_ADDR_OUTPUT_R_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Control_BaseAddress + XHAND_CORE_CONTROL_ADDR_OUTPUT_R_BASE + offset + i);
    }
    return length;
}

void XHand_core_InterruptGlobalEnable(XHand_core *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XHand_core_WriteReg(InstancePtr->Control_BaseAddress, XHAND_CORE_CONTROL_ADDR_GIE, 1);
}

void XHand_core_InterruptGlobalDisable(XHand_core *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XHand_core_WriteReg(InstancePtr->Control_BaseAddress, XHAND_CORE_CONTROL_ADDR_GIE, 0);
}

void XHand_core_InterruptEnable(XHand_core *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XHand_core_ReadReg(InstancePtr->Control_BaseAddress, XHAND_CORE_CONTROL_ADDR_IER);
    XHand_core_WriteReg(InstancePtr->Control_BaseAddress, XHAND_CORE_CONTROL_ADDR_IER, Register | Mask);
}

void XHand_core_InterruptDisable(XHand_core *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XHand_core_ReadReg(InstancePtr->Control_BaseAddress, XHAND_CORE_CONTROL_ADDR_IER);
    XHand_core_WriteReg(InstancePtr->Control_BaseAddress, XHAND_CORE_CONTROL_ADDR_IER, Register & (~Mask));
}

void XHand_core_InterruptClear(XHand_core *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XHand_core_WriteReg(InstancePtr->Control_BaseAddress, XHAND_CORE_CONTROL_ADDR_ISR, Mask);
}

u32 XHand_core_InterruptGetEnabled(XHand_core *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XHand_core_ReadReg(InstancePtr->Control_BaseAddress, XHAND_CORE_CONTROL_ADDR_IER);
}

u32 XHand_core_InterruptGetStatus(XHand_core *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XHand_core_ReadReg(InstancePtr->Control_BaseAddress, XHAND_CORE_CONTROL_ADDR_ISR);
}

