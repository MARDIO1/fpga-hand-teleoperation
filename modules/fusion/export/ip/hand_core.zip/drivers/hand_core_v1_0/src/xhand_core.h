// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XHAND_CORE_H
#define XHAND_CORE_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xhand_core_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
} XHand_core_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XHand_core;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XHand_core_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XHand_core_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XHand_core_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XHand_core_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XHand_core_Initialize(XHand_core *InstancePtr, UINTPTR BaseAddress);
XHand_core_Config* XHand_core_LookupConfig(UINTPTR BaseAddress);
#else
int XHand_core_Initialize(XHand_core *InstancePtr, u16 DeviceId);
XHand_core_Config* XHand_core_LookupConfig(u16 DeviceId);
#endif
int XHand_core_CfgInitialize(XHand_core *InstancePtr, XHand_core_Config *ConfigPtr);
#else
int XHand_core_Initialize(XHand_core *InstancePtr, const char* InstanceName);
int XHand_core_Release(XHand_core *InstancePtr);
#endif

void XHand_core_Start(XHand_core *InstancePtr);
u32 XHand_core_IsDone(XHand_core *InstancePtr);
u32 XHand_core_IsIdle(XHand_core *InstancePtr);
u32 XHand_core_IsReady(XHand_core *InstancePtr);
void XHand_core_EnableAutoRestart(XHand_core *InstancePtr);
void XHand_core_DisableAutoRestart(XHand_core *InstancePtr);

void XHand_core_Set_reset(XHand_core *InstancePtr, u32 Data);
u32 XHand_core_Get_reset(XHand_core *InstancePtr);
u32 XHand_core_Get_input_r_BaseAddress(XHand_core *InstancePtr);
u32 XHand_core_Get_input_r_HighAddress(XHand_core *InstancePtr);
u32 XHand_core_Get_input_r_TotalBytes(XHand_core *InstancePtr);
u32 XHand_core_Get_input_r_BitWidth(XHand_core *InstancePtr);
u32 XHand_core_Get_input_r_Depth(XHand_core *InstancePtr);
u32 XHand_core_Write_input_r_Words(XHand_core *InstancePtr, int offset, word_type *data, int length);
u32 XHand_core_Read_input_r_Words(XHand_core *InstancePtr, int offset, word_type *data, int length);
u32 XHand_core_Write_input_r_Bytes(XHand_core *InstancePtr, int offset, char *data, int length);
u32 XHand_core_Read_input_r_Bytes(XHand_core *InstancePtr, int offset, char *data, int length);
u32 XHand_core_Get_output_r_BaseAddress(XHand_core *InstancePtr);
u32 XHand_core_Get_output_r_HighAddress(XHand_core *InstancePtr);
u32 XHand_core_Get_output_r_TotalBytes(XHand_core *InstancePtr);
u32 XHand_core_Get_output_r_BitWidth(XHand_core *InstancePtr);
u32 XHand_core_Get_output_r_Depth(XHand_core *InstancePtr);
u32 XHand_core_Write_output_r_Words(XHand_core *InstancePtr, int offset, word_type *data, int length);
u32 XHand_core_Read_output_r_Words(XHand_core *InstancePtr, int offset, word_type *data, int length);
u32 XHand_core_Write_output_r_Bytes(XHand_core *InstancePtr, int offset, char *data, int length);
u32 XHand_core_Read_output_r_Bytes(XHand_core *InstancePtr, int offset, char *data, int length);

void XHand_core_InterruptGlobalEnable(XHand_core *InstancePtr);
void XHand_core_InterruptGlobalDisable(XHand_core *InstancePtr);
void XHand_core_InterruptEnable(XHand_core *InstancePtr, u32 Mask);
void XHand_core_InterruptDisable(XHand_core *InstancePtr, u32 Mask);
void XHand_core_InterruptClear(XHand_core *InstancePtr, u32 Mask);
u32 XHand_core_InterruptGetEnabled(XHand_core *InstancePtr);
u32 XHand_core_InterruptGetStatus(XHand_core *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
